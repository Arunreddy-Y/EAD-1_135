import CheckStrength from './Components/CheckStrength.jsx'
import Timer from './Components/Timer.jsx'
import './App.css';
function App() {
  return (
    <>
      <Timer />
      <CheckStrength />
    </>   
    
       
  );
}

export default App;
